package pl.jewusiak.pwdbneo4jproc;

import org.neo4j.graphdb.*;
import org.neo4j.procedure.*;

import java.time.LocalDate;
import java.util.Map;
import java.util.stream.Stream;

public class FlightProcedures {

  @Context
  public GraphDatabaseService db;


  public static class CreateFlightResult {
    public String flightId;
    public String flightNo;
    public String carrier;
    public String origin;
    public String dest;
    public String date;
    public double distance;

    public CreateFlightResult(String flightId, String flightNo, String carrier,
        String origin, String dest, String date, double distance) {
      this.flightId = flightId;
      this.flightNo = flightNo;
      this.carrier = carrier;
      this.origin = origin;
      this.dest = dest;
      this.date = date;
      this.distance = distance;
    }
  }

  @Procedure(name = "pl.jewusiak.pwdbneo4jproc.createcalc", mode = Mode.WRITE)
  @Description("Dodaje lot i oblicza dystans")
  public Stream<CreateFlightResult> createcalc(
      @Name("date") String date,
      @Name("flightNo") String flightNo,
      @Name("carrier") String carrier,
      @Name("origin") String origin,
      @Name("dest") String dest
  ) {
    if (date == null || flightNo == null || carrier == null || origin == null || dest == null) {
      throw new IllegalArgumentException("Brak parametrow wymaganycha: date, flightNo, carrier, origin, dest.");
    }
    //sprawdzenie popr. formatu
    LocalDate.parse(date);

    String cypher =
        "MATCH (o:Airport {faa: $originCode}) " +
            "MATCH (d:Airport {faa: $destCode}) " +
            "MATCH (al:Airline {carrier: $carrier}) " +
            "WITH o, d, al, point.distance(o.location, d.location) AS dist_m " +
            "WITH o, d, al, dist_m, (dist_m * 0.000621371) AS dist_miles " +
            "CREATE (f:Flight { " +
            "id: randomUUID(), " +
            "date: date($date), " +
            "flight_no: $flightNo, " +
            "distance: dist_miles " + 
            "}) " +
            "MERGE (f)-[:DEPARTED_FROM]->(o) " +
            "MERGE (f)-[:ARRIVED_AT]->(d) " +
            "MERGE (f)-[:OPERATED_BY_AIRLINE]->(al) " +
            "RETURN f.id AS flightId, f.flight_no AS flightNo, al.carrier AS carrier, " +
            "o.faa AS origin, d.faa AS dest, toString(f.date) AS date, f.distance AS distance";

    Map<String, Object> params = Map.of(
        "date", date,
        "flightNo", flightNo,
        "carrier", carrier,
        "originCode", origin,
        "destCode", dest
    );

    try (Transaction tx = db.beginTx()) {
      Result r = tx.execute(cypher, params);

      Map<String, Object> row = r.next();
      tx.commit();

      CreateFlightResult out = new CreateFlightResult(
          (String) row.get("flightId"),
          (String) row.get("flightNo"),
          (String) row.get("carrier"),
          (String) row.get("origin"),
          (String) row.get("dest"),
          (String) row.get("date"),
          ((Number) row.get("distance")).doubleValue()
      );

      return Stream.of(out);
    }
  }
}
